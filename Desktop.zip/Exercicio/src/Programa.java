import java.util.HashMap;

public class Programa {

	public static void main(String[] args) {

		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put(null, null)
		map.put(null, null)
		map.put(null, null)
		map.put(null, null)
		map.put(null, null)
		map.put(null, null)